import React from 'react';
import { ChevronDown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero = () => {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 hero-bg-mobile md:hero-bg-desktop"
      >
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="mb-8 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 leading-tight">
            {t('hero.title')}
          </h1>
          <h2 className="text-2xl md:text-4xl font-light text-blue-100 mb-6">
            Iglesia Cristiana Gracia y Gloria Sanford
          </h2>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-8"></div>
        </div>

        <p className="text-xl md:text-2xl text-blue-100 mb-8 font-light">
          {t('hero.welcome')}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a href="#live" className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
            {t('hero.joinUs')}
          </a>
          <a href="#services" className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 inline-block">
            {t('hero.viewServices')}
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce" style={{backgroundColor: 'transparent !important'}}>
        <ChevronDown className="h-8 w-8 text-white opacity-75" />
      </div>
    </section>
  );
};

export default Hero;